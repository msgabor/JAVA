package java_practice;

import java.util.Random;

public class RNG {
    
    public static void main(String[] args) {
    
    Random rand = new Random();
    double number;
    
        for (int i = 0; i < 100; i++) {   
        
            number = rand.nextDouble();
            System.out.println(number);
            
        }
    
        
 }

}
    

