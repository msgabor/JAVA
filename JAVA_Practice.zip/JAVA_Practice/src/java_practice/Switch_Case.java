package java_practice;

public class Switch_Case {
 
    	public static void main(String[] args) {
		
		System.out.println(" ");
		java.util.Scanner sc = new java.util.Scanner(System.in);
		
		System.out.println("Adj meg egy évszakot!");
		String evszak = sc.nextLine();
		
		switch (evszak) {		//beletesszĂĽk a vĂˇltozĂłt
		
		case "tél":
			System.out.println("A tél hideg évszak!");
			break;
		case "nyár":
			System.out.println("A nyár forró!");
			break;
		case "tavasz":
			System.out.println("Tavasszal dagad a f@sz!");
		case "ősz":
			System.out.println("Ősszel hullanak a levelek");	
			break;
			
		default: 
			System.out.println("Nem évszakot adtál meg!");
			break;
		
		}
		
		sc.close();
		
	}

}
