package java_practice;


public class Scanner {
    
    public static void main(String[] args) throws Exception{
    
        System.out.println("Irj be egy szĂˇmot Ă©s megduplĂˇzom! ");
		
        java.util.Scanner scanner = new java.util.Scanner(System.in);
		
        int number = scanner.nextInt();
        number = number * 2; 
		
        System.out.println("A szĂˇm duplĂˇzva: " + number);
		
        scanner.close();
    }
}