package java_practice;

import java.util.ArrayList;


public class Array_vs_ArrayList {
    
   

	public static void main(String[] args) {
		
		String[] simpleArray = new String[3];
		simpleArray[0] = "apple";
		simpleArray[1] = "vegetables";
		simpleArray[2] = "meat";
		int a = simpleArray.length; 	//ez tĂˇrolja el a nevĹ± vĂˇltozĂłba a 
		
		//discrepancies:
		
		ArrayList<String> list = new ArrayList<>();
		list.add("apple");
		list.add("vegetables");
		list.add("meat");
		list.get(1);
		//list.remove(0);
		int b = list.size();
		
		//objektumok tĂˇrolĂˇsa arraylist-ben
		
		
	

	}
}
