package java_practice;

import java.io.FileReader;
import java.io.File;
import java.io.FileNotFoundException;

public class Try_Catch_Finally {

	public static void main(String[] args) throws Exception{
		
		
		File file = new File("E://file.txt");
		
		try {	//ami try utĂˇn jĂ¶n, nem fagyunk meg, ha nem sikerĂĽl, akkor Ăˇtugrik catch-re
			FileReader fr = new FileReader(file);
                        
		}catch (FileNotFoundException e) {
			e.printStackTrace();
	
			
		}finally {
			//akĂˇr lefutott a try akĂˇr helyette a catch - ez mindenkĂ©ppen le fog futni az eredmĂ©nytĹ‘l fĂĽggetlenĂĽl
		}
		
		
	}

}

