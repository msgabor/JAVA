package java_practice;

import java.io.BufferedWriter;
import java.io.FileWriter;

public class Writing_Out {
    	public static void main(String[] args) throws Exception {
		
		FileWriter fw = new FileWriter("C:/Users/Messzi-Szabó Gábor/Desktop/IT_Dev/JAVA_Practice/kiiratas.txt");
		BufferedWriter writer = new BufferedWriter(fw);
		
		for (int i = 0; i < 19; i++) {
			
			writer.write(Integer.toString(i));
			writer.newLine();
			writer.flush();
		}
		writer.close();
	}

}

