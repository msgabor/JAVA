package java_practice;

public class Function_Overloading {
    
 public class function_overLoading {
	
	//function overload example
	
	public  function_overLoading(){
		
	}
	
	public  function_overLoading(String newName){
		
	}

	public  function_overLoading(String newName, int newAge){
	
	}
	public  function_overLoading(int newAge, String newName){
		
	}

    }
}