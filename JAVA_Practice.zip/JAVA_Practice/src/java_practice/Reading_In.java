package java_practice;

import java.io.File;

public class Reading_In {
    
    	public static void main(String[] args) throws Exception {		
		
		File file = new File("C:/Users/Messzi-Szabó Gábor/Desktop/IT_Dev/JAVA_Practice/input.txt");
		try {
			java.util.Scanner sc = new java.util.Scanner(file);
			while (sc.hasNextLine()) {		//ameddig van a file-unkban sor, addig fusson a ciklus
				String name = sc.nextLine();
				System.out.println(name);
				
			}
			sc.close();
			
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
		}

	}
}
