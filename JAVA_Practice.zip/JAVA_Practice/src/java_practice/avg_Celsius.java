package java_practice;

import java.util.Scanner;

public class avg_Celsius{
    
    public static void main(String[] args) {
        
    		Scanner scanner = new Scanner(System.in);
		int het[] = new int [7];
		
		for (int i = 0; i < het.length; i++) {
			System.out.println("Add meg a(z) " +(i+1)+ ". nap mért hőmérsékletett!");
			het[i] = scanner.nextInt();
		}
                
                
                
		double summa = 0;
		
                for (int x : het) {
			summa += x;
		}
		System.out.println("A heti hőmérsékletet átlaga: " + (summa / het.length + "fok!"));
	}

}