package java_practice;

public class Cast_ValueOf {
    
    public static void main(String[] args) {
		
		System.out.println( 1 + 1 + " String-kĂ©nt Ă©rtelmezĂ©s: " + 1);
		System.out.print("GabibĂˇcsi" + "\n");

		String string = "Gabi";
		
		int a = 22;
		//byte b = a; 						//ez nem fog menni, mert a nagyobb tipust akarom tĂ¶lteni a kisebb byte-ba
		
		byte x = 10;
		int y = x;							//ezt engedi, mert a nagyobbĂłl tĂ¶ltĂ¶m a kisebb tartomĂˇnyba
		System.out.println(x);
		//***********************************************************************************************************************
		char first = 'G';
		int second = 2;
		String third = ""+ first;			//Stringbe sem lehet konvertĂˇlni a char-t, erre az egyik megoldĂˇs		
		System.out.println("" + 1 + 1); 	//ugyanezt irom a first szĂłcska elĂ© Ă©s engedi, a G betĹ± belekerĂĽl a third nevĹ± Stringbe
		third = "" + second; 				//Ăşjra a trĂĽkk
		
		double d = 3.5;
		int i = (int) d;					//a tĂ¶rt szĂˇm miatt nem engedi, de leveszi a tizedest majd, de manuĂˇlisan ha elĂ© irom igen
		
		third = String.valueOf(second);		//Ăˇtadja a string Ă©rtĂ©kĂ©t a vĂˇltozĂłnak, ez a +1+1 es megoldĂˇs szintĂ©n
		
		//manuĂˇlis castolĂˇs
		Integer it = 10;
		String valami = it.toString();		//to stringgel manuĂˇlis konvertĂˇlĂˇs
		System.out.println(valami);
		
		Character c = 'd';
		
		Test(second); 						//wrapper miatt a lenti Integert, becsomagolja a secondnak megfelelĹ‘ int-be
	}
	
	public static void Test(Integer c) {
		System.out.println(c);
	}
}
