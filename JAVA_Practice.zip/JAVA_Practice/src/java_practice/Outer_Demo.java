package java_practice;

public class Outer_Demo {                       //külső osztály
	int num;
	
	//belő osztály
	private class Inner_Demo {		//mivel privát, ezért lent nem érem el a main függvényben
		public void print() {
			System.out.println("This is an inner class!");
		}
	}
	
	void display_Inner() {
		Inner_Demo inner = new Inner_Demo();
		inner.print();
	}

	
//******************************************************************************************
	
	public static void main(String[] args) {
		
		Outer_Demo outer = new Outer_Demo();
		outer.display_Inner();

		}
}
