package rectangular_area_counting;

import java.util.Scanner;
/**
 *
 * @author Messzi-Szabó Gábor
 */
public class Rectangular_Area_Counting {

    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Input the A side of the object: ");
        int a = scanner.nextInt();
        
        
        System.out.println("Input the B side of the object: ");
        int b = scanner.nextInt();
        
        int c = perimeter(a,b);
        int d = square(a,b);
        
        System.out.println("Perimeter of the object is: " + c);
        System.out.println("Square of the object is: " + d);
        
    }
    
    public static int perimeter(int a, int b){
        int c = (a + b) * 2;
        return  c;
    }
    
    public static int square(int a, int b){
        int d = a * b;
        return d;
    }
    
}
