
package javabasic;


public class JavaBasic_Animal_Main {

    public static void main(String[] args) {
        
        Cat cat = new Cat("Gabi", 15);		//konstruktoron keresztĂĽli paramĂ©ter ĂˇtadĂˇs
	//Animal animal = new Animal(); - abstract kulcs szĂł miatt nem lehet tĂ¶bbĂ© pĂ©ldĂˇnyositani
		
	cat.makeSound();
		
        cat.cuddle();	//interface Pet - implement Cat miatt elĂ©rhetĹ‘ek a tulajdonsĂˇgok
	cat.layDown();
	cat.sit();
		
	System.out.println("A macska neve: " + cat.getName() + ", az életkora: " + cat.getAge() );
		
	Dog.fart(); 		//static miatt pĂ©ldĂˇnyositĂˇs nĂ©lkĂĽl hivhatĂł a metĂłdus
    }
    
}
