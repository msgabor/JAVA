package javabasic;

public interface Pet {		//az interface Ă¶nmagĂˇban is abstract-ciĂł!
	
	public void cuddle();
	public void sit();
	public void layDown();
	

}