package javabasic;

public class Cat extends Animal implements Pet{		//Pet-et is implementĂˇljuk
	
	@Override		//jelzem, hogy az Ĺ‘sosztĂˇly is tudja, de hagyja figyelmen kivĂĽl Ă©s azt csinĂˇlja ami itt van!! felĂĽlirom az Ĺ�s viselkedĂ©sĂ©t
	public void makeSound() {
		System.out.println("MEOW");
	}
	
	//azĂ©rt hĂşzza alĂˇ a Cat-et, mert nem abstract a Cat, hanem kĂ¶telezĹ‘ overrideolni a Cat osztĂˇlyĂˇt a Pet tuljadonsĂˇgaival
	//kĂ¶telezĹ‘ overrideolni mindent ami megtalĂˇlhatĂł az interface class-ban
	
	public Cat(String name, int age) {			//KONSTRUKTOR
		this.name = name;
		this.age = age;
		super.makeSound();						//super kulccsal Ĺ‘sosztĂˇlybĂłl Ă©rem el a tulajdonsĂˇgokat
	}
	
	//FONTOS: KĂ–TELEZĹ� OVERRIDEOLNI mindent ami az interface Class-bĂłl jĂ¶n. viszont itt meg kell mondani mit csinĂˇljon
	@Override
	public void cuddle() {
		System.out.println("Ă¶lel");
	}

	@Override
	public void sit() {
		System.out.println("ĂĽl");
	}

	@Override
	public void layDown() {
		System.out.println("fexik");
	}
}