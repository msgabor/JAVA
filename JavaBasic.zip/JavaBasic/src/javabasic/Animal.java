package javabasic;

public abstract class Animal {		//abstract miatt soha tĂ¶bbĂ© nem pĂ©ldĂˇnyosithatĂł

	protected String name;
	protected int age;

	
	protected void makeSound() {			//ha private lenne, akkor a main-ben alĂˇhĂşzza, hogy nem elĂ©rhetĹ‘ a Cat pĂ©ldĂˇnyositĂˇsĂˇn keresztĂĽl
		System.out.println("AAAAAAAA");
	}
	
	
	
	public int getAge() {
		return age;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
        
}