package javabasic;

public final class Dog extends Animal {		//immutable class - nem terjeszthetĹ‘ ki tĂ¶bbĂ©
	
	final private int kutyus = 1;		//vĂˇltozĂł is lehet megvĂˇltoztathatatlan - immutable

	String a = "Heap-ben él";
	String b = new String("Heap-ben lakik, de a String Pool-ban!");
	
	public final void bark() {			//ezt meg nem lehet mĂˇr overrideolni
		
	}
	
	public static void fart() {			//static kulcsszĂł miatt pĂ©ldĂˇnyositĂˇs nĂ©lkĂĽl hivhatĂł a metĂłdus
		
	}
	
}
