
package polimorphysm;

public class Cat_Class extends Animal_Class{

	public void meow() {
		System.out.println("MEOW");
	}
        
}