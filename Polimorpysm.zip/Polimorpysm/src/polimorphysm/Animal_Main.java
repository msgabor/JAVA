
package polimorphysm;

public class Animal_Main {

    public static void main(String[] args) {
        
        	Cat_Class macska = new Cat_Class();
		
		macska.setName("Mirci");
		
		System.out.println(macska.getName());
		System.out.println(macska.equals(macska));
	}
    }
   
