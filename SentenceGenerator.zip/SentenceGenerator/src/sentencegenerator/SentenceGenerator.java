package sentencegenerator;

public class SentenceGenerator {

    public static void main(String[] args) {
        
        Game sentenceGenerator = new Game();
		
		System.out.println(sentenceGenerator.Generator());
		//5. lépés - az példány.generátorát kell meghivni
		
            
    }
   
}
