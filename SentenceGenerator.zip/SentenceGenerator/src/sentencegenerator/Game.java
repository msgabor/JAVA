package sentencegenerator;

public class Game {

    public String Generator() {
		
		//1. lépéss - létrehozzuk a tömböket
		String[] firstWord = {"Kiváló", "Megbizható", "Tökéletes","Hibátlan"};
		String[] secondWord = {"megoldás", "lehetőség", "kivitelezés","cselekvés"};
		String[] thirdWord = {"neked!", "mindenkinek!", "Az egész világnak!","senkinek sem!"};
	
		//2. lépés - el kell tároljuk a különböző méreteit a tömbjeinknek
		int firstLenght = firstWord.length;
		int secondLenght = secondWord.length;
		int thirdLenght = thirdWord.length;
		
		//3. lépés - random1 változó int-té cast-olása a Math.random-nak, valamint mivel 0-1 közötti, a tömb méretévelvel szorzás
		int random1 = (int) (Math.random() * firstLenght);
		int random2 = (int) (Math.random() * secondLenght);
		int random3 = (int) (Math.random() * thirdLenght);
		
		//4. lépés, létrehozzuk a mondatot, szintén tömbökben
		String finalSentence = firstWord[random1] + " " + secondWord[random2] + " " + thirdWord[random3];
	
		return finalSentence;
	}
}
