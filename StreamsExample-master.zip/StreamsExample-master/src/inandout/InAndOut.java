
package inandout;

import java.io.IOException;


public class InAndOut {


    public static void main(String[] args) throws IOException {
//        Writer w = new Writer();
//        w.bufferedWriter();
        Reader r = new Reader();
        r.readMultipleCharacters();
//        int something = System.in.read();
//        System.out.println((char) something);
//          System.err.println("Baj van Gyula!");
    }
    
}
